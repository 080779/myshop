// pages/home/home.js
const tween = require('../../utils/Tween.js');
const app = getApp();
Page({
  data: {
    slide: {},
    notice: {},
    goodstype: {},
<<<<<<< HEAD
    // hotgoods: {},
=======
    hotgoods: {},
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
    pageindex: 1,
    pagesize: 10,
    onReachBottom: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
    this.getslide();
    this.getnotice();
    this.getgoodstype();
    // this.gethotgoods();
    console.log(tween);
  },
<<<<<<< HEAD
  onLoad: function(){
    app.requestData({
      "url": "/api/goods/hotsales",
      "subData": {
        "pageindex": this.data.pageindex,
        "pagesize": this.data.pagesize,
      },
      "success": res => {
        if (res.status) {
          this.setData({
            hotgoods: res.data
          })
        }
      }
    });
=======
  onLoad: function () {
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
  },

  // 幻灯片
  getslide: function () {
    app.requestData({
      "url": "/api/slide/list",
      "success": res => {
        if (res.status) {
          this.setData({
            slide: res.data
          })
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  // 公告
  getnotice: function () {
    app.requestData({
      "url": "/api/notice/list",
      "success": res => {
        if (res.status) {
          this.setData({
            notice: res.data
          })
        } else {
          app.showTips(res.msg);
        }
        console.log(this.data)
      }
    });
  },
  // 图标
  getgoodstype: function () {
    app.requestData({
      "url": "/api/goodstype/list",
      "success": res => {
        if (res.status) {
          app.globalData.goodstype = res.data;
          this.setData({
            goodstype: res.data
          })
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  // 热销商品
<<<<<<< HEAD
  // gethotgoods: function() {
  //   app.requestData({
  //     "url": "/api/goods/hotsales",
  //     "success": res => {
  //       if (res.status) {
  //         this.setData({
  //           hotgoods: res.data.goods
  //         })
  //       } else {
  //         app.showTips(res.msg);
  //       }
  //     }
  //   });
  // },
  setclassid: function(e) {
=======
  gethotgoods: function() {
    app.requestData({
      "url": "/api/goods/hotsales",
      "subData": {
        "pageindex": this.data.pageindex,
        "pagesize": this.data.pagesize,
      },
      "success": res => {
        if (res.status) {
          this.setData({
            hotgoods: res.data
          })
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  setclassid: function (e) {
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
    app.globalData.classid = e.currentTarget.dataset.classid
  },
  //拿到输入值
  wxSearchInput: function (e) {
    var val = e.detail.value;
    this.setData({
      inputval: val
    });
<<<<<<< HEAD
    var that=this;
    if (val){
=======
    var that = this;
    if (val) {
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
      wx.navigateTo({
        url: '/pages/search/search?keyword=' + val
      })
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      pageindex: 1
    })
    //模拟加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
    this.gethotgoods();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var index = this.data.pageindex;
    this.setData({
      pageindex: index + 1
    })
    console.log('上拉加载');
    if (this.data.onReachBottom == true) {
      app.requestData({
        "url": "/api/goods/hotsales",
        "subData": {
          "pageindex": this.data.pageindex,
          "pagesize": this.data.pagesize,
        },
        "success": res => {
          if (res.status) {
            var newhotgoods = this.data.hotgoods;
            console.log(newhotgoods)
            var len = res.data.goods.length;
            if (len <= 0) {
              this.setData({
                onReachBottom: false,
              })
            }
            for (var i = 0; i < len; i++) {
              newhotgoods.goods.push(res.data.goods[i]);
            }
            this.setData({
              hotgoods: newhotgoods
            })
          }
        }
      });
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      pageindex: 1
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var index = this.data.pageindex;
    this.setData({
      pageindex: index + 1
    })
    console.log('上拉加载');
    if (this.data.onReachBottom == true) {
      app.requestData({
        "url": "/api/goods/hotsales",
        "subData": {
          "pageindex": this.data.pageindex,
          "pagesize": this.data.pagesize,
        },
        "success": res => {
          if (res.status) {
            var newhotgoods = this.data.hotgoods;
            console.log(newhotgoods)
            var len = res.data.goods.length;
            if (len <= 0) {
              this.setData({
                onReachBottom: false,
              })
            }
            for (var i = 0; i < len; i++) {
              newhotgoods.goods.push(res.data.goods[i]);
            }
            this.setData({
              hotgoods: newhotgoods
            })
          }
        }
      });
    }
  },
})