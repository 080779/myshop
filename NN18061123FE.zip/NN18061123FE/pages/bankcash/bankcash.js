const app = getApp();
Page({
  data:{
    bank:{
      bankAccount: "",
      bankName: "",
      name: "",
    },
    sends: false,
  },
  onLoad:function(){
    app.requestData({
      "url": "/api/bankAccount/info",
      "subData": this.data.bank,
      "success": res => {
        if (res.status) {
          this.setData({
            bank:res.data
          })
        }
      }
    });
  },
  //监听输入事件
  changeinput: function (even) {
    var name = even.currentTarget.dataset.name;
    this.data.bank[name] = even.detail.value;
  },
  savebank:function(){
    console.log(this.data.bank);
    if (this.data.bank.bankAccount == null) {
      app.showTips('请输入银行卡号')
      return false;
    }
    if (this.data.bank.bankName == null) {
      app.showTips('请输入开卡银行')
      return false;
    }
    if (this.data.bank.name == null) {
      app.showTips('请确认持卡人姓名')
      return false;
    }
    if (this.data.sends) {
      return false;
      this.setData({
        sends: true
      });
    } else if (this.data.sends){
      app.requestData({
        "url": "/api/bankAccount/edit",
        "subData": this.data.bank,
        "success": res => {
          if (res.status) {
            app.showTips(res.msg, function () {
              wx.navigateBack({
                delta: 1
              })
            })
          } else {
            this.setData({
              sends: false
            });
            app.showTips(res.msg)
          }
        }
      });
    }
  },
})