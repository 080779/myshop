/** pages/ordersitem/ordersitem.js*/
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    endTime:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    app.requestData({
      "url": "/api/order/detail",
      "subData": options,
      "success": res => {
        if (res.status) {
          this.setData({
            list: res.data,
            goods: res.data.OrderGoods,
          });
          if (res.data.endTime.length>0){
            this.setData({
              endTime: res.data.endTime.replace("T", " ").split("", 16).join(""),
            })
          }
        }
      }
    });

  },

})