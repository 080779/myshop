// pages/addaddress/addaddress.js
// switch组件（开关选择器）
var pageObj = {
  data: {
    isChecked: false,
  }
};
for (var i = 0; i < 2; ++i) {
  (function (i) {
    pageObj['changeSwitch' + i] = function (e) {
      var changedData = {};
      changedData['isChecked' + i] = !this.data['isChecked' + i];
      this.setData(changedData);
    }
  })(i)
}
Page({
  /**输入文字input为空 */
  setValue: function () {
    this.setData({
      value: ""
    })
  },
})