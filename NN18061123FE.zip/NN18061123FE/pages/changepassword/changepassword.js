const app = getApp();
Page({
  data: {
    password: "",
    newpassword: "",
    renewpassword: "",
    // newTradePassword: "",
    sends: false,
  },
  onLoad: function() {},

  //监听输入事件
  changeinput: function(even) {
    var name = even.currentTarget.dataset.name;
    this.data.bank[name] = even.detail.value;
  },

  // 原密码
  password: function(e) {
    this.setData({
      password: e.detail.value
    })
  },
  // 获取输入新密码
  newpassword: function(e) {
    this.setData({
      newpassword: e.detail.value
    })
  },
  // 确认新新密码
  renewpassword: function(e) {
    this.setData({
      renewpassword: e.detail.value
    })
  },
  //获取新交易密码
  // newTradePassword: function(e) {
  //   this.setData({
  //     newTradePassword: e.detail.value
  //   })
  // },
  //保存输入值
  saveval: function() {
    if (!this.data.password.length) {
      app.showTips('请输入原密码')
      return false;
    }
    if (!this.data.newpassword.length) {
      app.showTips('请输入新密码')
      return false;
    }
    if (!this.data.renewpassword.length) {
      app.showTips('请确认新密码')
      return false;
    }
    // if (!this.data.newTradePassword.length) {
    //   app.showTips('请输入新交易密码')
    //   return false;
    // }
    if (this.data.sends) {
      return false;
    }
    this.setData({
      sends: true
    });
    app.requestData({
      "url": "/api/usercenter/resetPwd",
      "subData": {
        "password": this.data.password,
        "newpassword": this.data.newpassword,
        "renewpassword": this.data.renewpassword,
        // "newTradePassword": this.data.newTradePassword,
      },
      "success": res => {
        if (res.status) {
          app.showTips(res.msg, function() {
            wx.navigateBack({
              delta: 1
            })
          })
        } else {
          this.setData({
            sends: false
          });
          app.showTips(res.msg)
        }
      }
    });
  },
})