// pages/personal/personal.js
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    changeval:false,
    userInfo:"",
    updateinfo:{
      headPic: "",
      qrcode: "",
      nickName: "",
    },
  },
  onLoad: function (options) {
  
  },
  onShow: function () {
    this.setData({
      userInfo: app.globalData.userInfo
    });
  },
  onShareAppMessage: function () {
  
  },
  chooseImage: function (even){
    var that = this;
    var name = even.currentTarget.dataset.name;
    var updateinfo = this.data.updateinfo;
    wx.chooseImage({
      count: 1, // 默认9
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        var tempFilePaths = res.tempFilePaths;
        var url = 'http://1823.demo.wohuicn.com/api/usercenter/editheadpic';
        if (name =='qrcode'){
          url = 'http://1823.demo.wohuicn.com/api/usercenter/editqrcode';
        }
        wx.uploadFile({
          url: url, //仅为示例，非真实的接口地址
          filePath: tempFilePaths[0],
          name: 'file',
          header: {
            "token": app.globalData.userInfo.token,
          },
          success: function (res) {
            var data = JSON.parse(res.data);
            console.log(data);
            
            if (data.status){
              //do something
              updateinfo[name] = data.data;
              // // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
              // conso
              that.setData({
                updateinfo: updateinfo
              });
              app.globalData.userInfo[name] = data.data;
            }
            console.log(app.globalData.userInfo);
          }
        })
      }
    })
  },
  changeinput: function (even) {
    var value = even.detail.value;
    var updateinfo = this.data.updateinfo;
    updateinfo.nickName = value
    this.setData({
      updateinfo: updateinfo,
      changeval:true,
    })
  },
  saveuserinfo:function(){
    var that = this;
    var info = this.data.updateinfo;
    if (info.nickName){
      app.requestData({
        "url":"/api/usercenter/editnickname",
        "subData": { nickname: info.nickName},
        "success":res=>{
          if(res.status){
            app.globalData.userInfo.nickname = info.nickName;
            that.setData({
              changeval: false,
            })
          }else{
            that.setData({
              userInfo: app.globalData.userInfo
            });
          }
        },
      });
    }
    if (info.headPic){
      that.setData({
        headPic: app.globalData.headPic
      });
    }
  },
  logout:function(){
    wx.removeStorage({
      key: 'token',
      success: function (res) {
        wx.redirectTo({
          url: '/pages/login/login'
        })
      }
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    //模拟加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
})
