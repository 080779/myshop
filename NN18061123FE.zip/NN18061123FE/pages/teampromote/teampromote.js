// pages/teampromote/teampromote.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    share:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getshare();
    this.setData({
      userInfo: app.globalData.userInfo
    });
  },

  getshare: function () {
    app.requestData({
      "url": "/api/share/get",
      "success": res => {
        if (res.status) {
          this.setData({
            share: res.data
          });
        }
      }
    });
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    //模拟加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
})