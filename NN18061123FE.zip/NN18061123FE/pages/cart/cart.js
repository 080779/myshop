const app = getApp();
Page({
  data: {
    list:[],
    allSelect:false,
    num:0,
    count:0,
    hasselect:false,
  },
  //改变选框状态
  change:function(e){
    var that=this
    //得到下标
    var index = e.currentTarget.dataset.index
    //得到选中状态
    var select = e.currentTarget.dataset.select
    
    //得到点击的值
    var num = e.currentTarget.dataset.number;

    //得到商品id
    var id = e.currentTarget.dataset.id;

    //把新的值给新的数组
   var newList= that.data.list;
   
   app.requestData({
     "url": "/api/goodscar/edit",
     "subData": { "id": id, "isSelected": !select },
     "success": res => {
       if (res.status) {
        select = !select;
       } else {
         app.showTips(res.msg);
       }
       newList[index].isSelected = select;
       //把新的数组传给前台
       that.setData({
         list: newList
       })
       //调用计算数目方法
       that.countNum()
       //计算金额
       that.count()
     }
   });
  },
  //加法
  addtion:function(e){
    var that=this
    //得到下标
    var index = e.currentTarget.dataset.index;
    //得到点击的值
    var num = e.currentTarget.dataset.number;

    //得到商品id
    var id = e.currentTarget.dataset.id;
    var newList = that.data.list;

    app.requestData({
      "url": "/api/goodscar/add",
      "subData": { "id": id,"number":1},
      "success": res => {
        if (res.status) {
          num++
          //把新的值给新的数组
          newList[index].number = num

          //把新的数组传给前台
          that.setData({
            list: newList
          })
          //调用计算数目方法
          that.countNum()
          //计算金额
          that.count()
        } else {
          app.showTips(res.msg);
        }
        // console.log(this.data)
      }
    });
    // that.setData({
    //   count: newCount.toFixed(2)//保留小数点后两位
    // })
  },
  //减法
  subtraction:function(e){
    var that = this
    //得到下标
    var index = e.currentTarget.dataset.index
    //得到点击的值
    var num = e.currentTarget.dataset.number
    //把新的值给新的数组
    var newList = that.data.list
    //当1件时，点击移除
    if (num == 1) {
        return false;
    }

    //得到商品id
    var id = e.currentTarget.dataset.id;
    app.requestData({
      "url": "/api/goodscar/add",
      "subData": { "id": id, "number": 1 },
      "success": res => {
        if (res.status) {
          num--
          newList[index].number = num
          //把新的数组传给前台
          that.setData({
            list: newList
          })
          //调用计算数目方法
          that.countNum()
          //计算金额
          that.count()
        } else {
          app.showTips(res.msg);
        }
      }
    });

  },
  //删除
  removegood:function(e){
    var that = this
    //得到下标
    var index = e.currentTarget.dataset.index;
    var id = e.currentTarget.dataset.id;
    var newList = that.data.list;

    app.requestData({
      "url": "/api/goodscar/del",
      "subData": { "id": id },
      "success": res => {
        if (res.status) {
          newList.splice(index, 1);
          //把新的数组传给前台
          that.setData({
            list: newList
          })
          //调用计算数目方法
          that.countNum()
          //计算金额
          that.count()
        }else{
          app.showTips(res.msg);
        }
      }
    });
  },

  //全选
  allSelect:function(e){
    var that=this
    //先判断现在选中没
    var allSelect = !this.data.allSelect;
    var newList = that.data.list;
    var msg = '';
    for (var i = 0; i < newList.length; i++) {
      (function(i){
        app.requestData({
          "url": "/api/goodscar/edit",
          "subData": { "id": newList[i].id, "isSelected": allSelect },
          "success": res => {
            if (res.status) {
              newList[i].isSelected = allSelect;
            }
            that.setData({
              list: newList,
              allSelect: allSelect
            })
            //调用计算数目方法
            that.countNum()
            //计算金额
            that.count()
          }
        });
      })(i);
    }
  },
  //计算数量
  countNum:function(){
    var that=this;
    //遍历数组，把既选中的num加起来
    var newList = that.data.list
    var allNum=0
    var hasselect = false;
    var allselected = newList.length && true;
    
    for (var i = 0; i < newList.length; i++) {
      if (newList[i].isSelected){
        hasselect = true;
        allNum += parseInt(newList[i].number) 
      }else{
        allselected = false;
      }
    }

    that.setData({
      "allSelect": allselected,
      "hasselect": hasselect,
    })

    that.setData({
      num:allNum
    })
  },
  //计算金额方法
  count:function(){
    var that=this 
    //思路和上面一致
    //选中的订单，数量*价格加起来
    var newList = that.data.list
    var newCount=0
    for(var i=0;i<newList.length;i++){
      if (newList[i].isSelected){
        newCount += newList[i].number * newList[i].realityPrice
      }
    }
    that.setData({
       count: newCount.toFixed(2)//保留小数点后两位
    })
  },
  //立即下单
  orderplace:function(){
    app.requestData({
      "url":"/api/order/places",
      "success":res=>{
        if(res.status){
          wx.navigateTo({
            url: '/pages/payment/payment'
          })
        }else{
          app.showTips(res.msg);
        }
      }
    });
  },
  onShow:function(){
    var that = this;
    app.requestData({
      "url":"/api/goodscar/list",
      "success":res=>{
        if(res.status){
          that.setData({
            "list": res.data.goodsCars
          });
          //调用计算数目方法
          that.countNum()
          //计算金额
          that.count()
        }else{
          app.showTips(res.msg);
        }
      }
    });
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    //模拟加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },
})