// pages/addaddress/addaddress.js
// switch组件（开关选择器）
const app = getApp();
Page({
  data: {
    address: {
      name: '',
      mobile: '',
      address: '',
      isDefault: false,
    },
    sendData:false,
  },
  onLoad: function (option) {
    if (option.id) {
      app.requestData({
        "url": "/api/address/detail",
        "subData":{"id":option.id},
        "success": res => {
          if (res.status) {
            this.setData({
              address: res.data
            })
          }
        }
      });
    }
  },
  //监听输入事件
  changeinput: function (even) {
    var name = even.currentTarget.dataset.name;
    var address = this.data.address;
    var mobile = this.data.mobile;
    address[name] = even.detail.value;
    this.setData({
      "address": address
    })
  },
  //开默认
  changeSwitch:function(e){
    this.data.address.isDefault = e.detail.value;
  },
  //保存地址
  saveaddress:function(){
    this.setData({
      sendData: !this.data.sendData
    })
    if (this.data.sendData==true) {
      return false;
    }
    if(this.data.address.id){
      var url = '/api/address/edit';
    }else{
      var url = '/api/address/add';
    }
    app.requestData({
      "url": url,
      "subData": this.data.address,
      "success":res=>{
        if(res.status){
          app.showTips(res.msg,function(){
            wx.navigateBack({
              delta: 1
            })
          })
        }else{
          app.showTips(res.msg)
        }
        this.setData({
          sendData: true
        })
      }
    });
  },
});