// pages/myaccount/myaccount.js
const app = getApp();
Page({
  data: {
    list:[{
      price:'3943.58'
    }],
    amount:"",
    payTypeId:0,
    userinfo:'',
    bankAccount:[],
    send:true,
    sendData:false,
  },
  //监听输入事件
  changeinput: function (even) {
    var amount = this.data.amount;
    amount = even.detail.value;
    this.setData({
      amount: amount
    })
  },
  //用户信息
  getuserinfo:function(){
    app.requestData({
      "url": "/api/usercenter/info",
      "success": res => {
        if (res.status) {
          this.setData({
            userinfo: res.data
          });
        }
      }
    });
  },
  //是否有银行卡
  bankAccount:function(){
    app.requestData({
      "url": "/api/usercenter/detail",
      "success": res => {
        if (res.status) {
          this.setData({
            bankAccount: res.data.bankAccount,
            qrCode: res.data.qrCode
          });
        }  
      }
    });
  },
  //全部提现
  allwithdrawal:function(){
    this.setData({
      amount: this.data.userinfo.amount
    })
  },
  //选择提现方式
  changecheck: function (e) {
    var id = this.data.payTypeId;
    id = e.detail.value;
    console.log('方式' + id + this.data.payTypeId)

    this.setData({
      payTypeId: id
    })
    if (this.data.bankAccount != '' && this.data.payTypeId == 58) {
      this.setData({
        send: true
      })
    }
    if (this.data.qrCode != '' && this.data.payTypeId == 57) {
      this.setData({
        send: true
      })
    }
  },
  //确认提现
  clickbtn: function () {
    var that = this;
    var amount = this.data.amount;
    var payTypeId = this.data.payTypeId;
    if (this.data.bankAccount == '' && this.data.payTypeId== 58){
      app.showTips('请先添加银行卡');
      this.setData({
        send:false
      })
   }
    if (this.data.qrCode == '' && this.data.payTypeId == 57 ) {
      app.showTips('请先添加收款码');
      this.setData({
        send: false
      })
    }
    if (this.data.sendData) {
      return false;
    }
    this.setData({
      sendData:true
    })
    if (this.data.send==true){
        app.requestData({
          "url": "/api/takecash/apply",
          "subData": {
            "payTypeId": payTypeId,
            "amount": amount * 1,
          },
          "success": res => {
            if (res.status) {
              console.log("=======================")
              app.showTips(res.msg,function(){
                that.getuserinfo();//更新余额
                //输入框归零
                that.setData({
                  amount: ""
                })
              })
            } else {
              app.showTips(res.msg)              
            }
            this.setData({
              sendData: false
            })
            // console.log(this.data)
          },
        });
      }
   
  },
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.bankAccount();//是否有银行卡
    app.requestData({
      "url": "/api/takecash/paytypes",
      "success": res => {
        if (res.status) {
          this.setData({
            items: res.data,
            payTypeId: res.data[0].id,
          });
        }else{
          app.showTips('请先添加收款码或银行卡');
        }
      }
    });
<<<<<<< HEAD
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getuserinfo();
  },
=======
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865

    this.getuserinfo();
    
  },
})