// pages/return/return.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputval:'',
    inputvalue:'',
    sendData:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      orderId: options.orderId,
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  //获取快递名称
  deliverName:function(e){
    var val = e.detail.value;
    this.setData({
      inputval: val
    });
    var that = this;
  },
  //获取快递单号
  deliverCode: function (e) {
    var val = e.detail.value;
    this.setData({
      inputvalue: val
    });
    var that = this;
  },
  //提交
  returnDeliver:function(){
    this.setData({
      sendData: !this.data.sendData
    })
    if (this.data.sendData == true) {
      return false;
    }
    app.requestData({
      "url": '/api/return/adddeliver',
      "subData": { "orderid": this.data.orderId, "deliverName": this.data.inputval, "deliverCode": this.data.inputvalue },
      "success": res => {
        if (res.status) {
          app.showTips(res.msg,function(){
            wx.navigateBack()
          });  
        } else {
          app.showTips(res.msg);
        }
        this.setData({
          sendData: false
        })
      }
    });
  },

})