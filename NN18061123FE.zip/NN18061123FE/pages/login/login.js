//login.js
const util = require('../../utils/util.js')
const app = getApp();
Page({
  data: {
    phone: '',
    password: '',
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
  },
  onLoad: function () {
    app.globalData.userInfo.token = wx.getStorageSync('token') || ""
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        app.globalData.userInfo.code = res.code
        if (app.globalData.userInfo.token){
          wx.switchTab({
            url: '/pages/home/home'
          })
        }
      }
    })
  },
  // 获取输入账号
  phoneInput: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },

  // 获取输入密码
  passwordInput: function (e) {
    this.setData({
      password: e.detail.value
    })
  },

  // 登录
  login: function () {
    if (this.data.phone.length == 0 || this.data.password.length == 0) {
      app.showTips('信息不能为空');
    } else {
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        "url": 'http://1823.demo.wohuicn.com/api/user/login',
        "data": { "mobile": this.data.phone, "password": this.data.password, "code": app.globalData.userInfo.code },
        "method": "POST",
        "header": {
          'content-type': 'application/json',
        },
        "success": function (res) {
          var data = res.data;
          setTimeout(function () {
            wx.hideLoading()
          }, 20)
          if (data.status == 1) {
            wx.setStorageSync('token', data.data.token);
            app.globalData.userInfo.token = data.data.token;
            wx.switchTab({
              url: '/pages/home/home'
            })
          } else {
            app.showTips(data.msg);
          }
        },
        "fail": function (res) {
        }
      })
    }
  },
  bindGetUserInfo: function (e) {
    this.login();
  }
})

