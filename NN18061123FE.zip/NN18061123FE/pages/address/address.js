// pages/address/address.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    defaultadd: {},
    backurl: "",
    pageindex: 1,
<<<<<<< HEAD
    pagesize: 5
=======
    pagesize: 10
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.back) {
      this.setData({
        backurl: options.back
      });
    }
    this.setData({
      defaultadd: app.globalData.defaultadd
    })
    this.setData({
      delete: app.globalData.defaultadd
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getlist();
<<<<<<< HEAD
  },
  //编辑
  change: function (e) {
=======
  },
  //点击事件
  clickRadio:function(e){
console.log(e)
  },
  //编辑
  change: function (e) {
    var that=this;
    
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
    if (this.data.backurl) {
      wx.navigateBack({
        delta: 1
      })
    } else {
      app.requestData({
        "url": '/api/address/edit',
        "subData": this.data.list[e.target.dataset.index],
        "success": res => {
          if (res.status) {
            that.setData({
              defaultadd: this.data.list[e.target.dataset.index]
            })
          } else {
            app.showTips(res.msg)
          }
        }
      });
    }
    app.globalData.defaultadd = this.data.list[e.target.dataset.index];
  },
  //删除
  delete: function (e) {
    var list = this.data.list;
    var that = this;
    if (this.data.backurl) {
      wx.navigateBack({
        delta: 1
      })
    } else {
      app.requestData({
        "url": "/api/address/del",
        "subData": { id: e.currentTarget.dataset.id },
        "success": res => {
          if (res.status) {
            list.splice(e.target.dataset.index, 1);
            that.setData({
              list: list
            });
          } else {
            app.showTips(res.msg)
          }
        }
      });
    }

  },
  getlist: function () {
    app.requestData({
      "url": "/api/address/list",
      "subData": {
        "pageindex": this.data.pageindex,
        "pagesize": this.data.pagesize,
      },
      "success": res => {
        if (res.status) {
          this.setData({
<<<<<<< HEAD
            list: res.data
=======
            list: res.data.addressList
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
          })
        }
      }
    });
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      pageindex: 1
    })
<<<<<<< HEAD
=======
    //模拟加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
    this.getlist();
    // wx.stopPullDownRefresh();
    // console.log(this.list)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var index = this.data.pageindex;
    this.setData({
      pageindex: index + 1
    })
    console.log('上拉加载');
    app.requestData({
      "url": "/api/address/list",
      "subData": {
        "pageindex": this.data.pageindex,
        "pagesize": this.data.pagesize,
      },
      "success": res => {
        if (res.status) {
          var newlist=this.data.list;
          var len = res.data.length;
          for(var i=0;i<len;i++){
            newlist.push(res.data[i]);
          }
          this.setData({
            list: newlist
          })
        }
<<<<<<< HEAD
        console.log(this.data.list)
=======
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
      }
    });
  },
})