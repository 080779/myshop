// pages/shop/shop.js
var app = getApp()
Page({
  data: {
    list:[],
    levels: [],
    currentTab: 0,
    pagesize:10,
    pageindex:1,
    contHeight:400,
    onReachBottom:true
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    this.getlevels();
    this.getlist();
  },
  //点击切换
  clickTab: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current,
        onReachBottom: true,//上拉刷新
        pageindex: 1,
      })
    }
  },
  swiperTab: function (e) {
    var tid = this.data.list[this.data.currentTab];
    this.setData({
      currentTab: e.detail.current,
      onReachBottom:true,
      pageindex: 1,
    });
    this.getlist();
    if (tid) {
      this.setData({
        contHeight: tid.length * 220
      })
    }
  },
  getlist: function () {
    var list = this.data.list;
    var subData = { "pageindex": this.data.pageindex, "pagesize": this.data.pagesize };
    if (this.data.currentTab) {
      subData["teamLevelId"] = this.data.levels[this.data.currentTab].id;
    }
    app.requestData({
      "url": "/api/userteam/list",
      "subData": subData,
      "success": res => {
        if (res.status) {
          var len = res.data.members.length;
          if (len <= 0) {
            this.setData({
              onReachBottom: false//关闭刷新
            })
          }
          list[this.data.currentTab] = res.data.members;
          var newHeight = 220 * len ;//新高度
          this.setData({
            list: list,
            contHeight: newHeight,
          });
          wx.setNavigationBarTitle({
            "title": '我的团队(' + res.data.totalCount+'人)'
          })
          
        }
      }
    });
  },
  getlevels: function () {
    app.requestData({
      "url": "/api/userteam/levels",
      "success": res => {
        if (res.status) {
          var levels = [{ "id": 0, "name": "全部" }]
          for (var n = 0; n < res.data.length; n++) {
            levels.push(res.data[n]);
          }
          this.setData({
            levels: levels
          });
        }
      }
    });
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    //模拟加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var idx = this.data.pageindex+1;
    this.setData({
      pageindex:idx
    })
    var list = this.data.list;
    var subData = { "pageindex": this.data.pageindex, "pagesize": this.data.pagesize };
    if (this.data.currentTab) {
      subData["teamLevelId"] = this.data.levels[this.data.currentTab].id;
    }
    app.requestData({
      "url": "/api/userteam/list",
      "subData": subData,
      "success": res => {
        if (res.status) {
          var len = res.data.members.length;
          if (len <= 0) {
            this.setData({
              onReachBottom: false//关闭刷新
            })
          }
          // list[this.data.currentTab] = res.data.members;
          var newHeight = 220 * len + this.data.contHeight;//新高度
          var newlist = this.data.list;  
          for (var i = 0; i < len; i++) {
            newlist[this.data.currentTab].push(res.data.members[i]);
            
          }
          this.setData({
            list: newlist,
            contHeight: newHeight,
          });
          wx.setNavigationBarTitle({
            "title": '我的团队(' + res.data.totalCount + '人)'
          })
        }
      }
    });
  },

})