// pages/forget/forget.js
const util = require('../../utils/util.js')
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',
    password: '',
    person: '',
    num: '',
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    sends: false,
    sendnum: 60,
  },
  // 获取输入账号
  phoneInput: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },

  // 获取输入密码
  passwordInput: function (e) {
    this.setData({
      password: e.detail.value
    })
  },
  // 获取输入验证码
  numInput: function (e) {
    this.setData({
      num: e.detail.value
    })
  },
  sendnum: function () {
    var that = this;
    var sendnum = that.data.sendnum;
    sendnum--
    if (sendnum > 0) {
      that.setData({
        sendnum: sendnum
      });
      setTimeout(function () {
        that.sendnum();
      }, 1000);
    } else {
      that.setData({
        sends: false,
        sendnum: 60
      });
    }

  },
  sendcode: function () {
    var that = this;
    if (this.data.sends) {
      return false;
    }
    if (this.data.phone.length == 0) {
      wx.showToast({
        title: '信息不能为空',
        icon: 'loading',
        duration: 2000
      })
    } else {
      this.setData({
        sends: true,
      });
      wx.request({
        "url": 'http://1823.demo.wohuicn.com/api/user/sendmsg',
        "data": {
          "mobile": this.data.phone,
        },
        "method": "POST",
        "header": {
          'content-type': 'application/json',
        },
        "success": function (res) {
          var data = res.data;
          if (data.status) {
            app.showToast({
              "tiptxt": "发送成功"
            });
            that.sendnum();
          } else {
            app.showTips(data.msg);
            this.setData({
              sends: false,
            });
          }
        },
        "fail": function (res) {
        }
      })
    }
  },
  //**发送修改密码请求 */
  forget:function(){
    if (this.data.phone.length == 0) {
      app.showTips('手机号不能为空')
      return false;
    }
    if (this.data.password.length == 0) {
      app.showTips('新密码不能为空')
      return false;
    }
    if (this.data.num.length == 0) {
      app.showTips('验证码不能为空')
      return false;
    }
    wx.request({
      "url": "http://1823.demo.wohuicn.com/api/user/forgetpwd",
      "data": {"code": this.data.num, "mobile": this.data.phone, "password": this.data.password},
      "method": "POST",
      "header": {
        'content-type': 'application/json',
      },
      "success": function (res) {
        if (res.data.status) {
          app.showTips(res.data.msg,function(){
            wx.navigateTo({
              url: '/pages/login/login'
            })
          });
        } else {
          app.showTips(res.data.msg);
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})