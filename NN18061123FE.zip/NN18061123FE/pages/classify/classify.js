// pages/shop/shop.js
var app = getApp();
Page({
  data: {
    goodslist: {},
    scrollLeft: 0, //tab标题的滚动条位置
    goodstype: [],
    currentTab: 0,
<<<<<<< HEAD
=======
    pageindex:1,
    pagesize:10,//几条数据
    onReachBottom:true,
    contHeight:360,
    typeid:''
    
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
  },
  onLoad: function () {
    this.setData({
      "goodstype": app.globalData.goodstype,
    });
    this.getgoodslist();
    this.getgoodstype();
    
  },
  onShow: function () {
    for (var i = 0; i < this.data.goodstype.length; i++) {
      if (this.data.goodstype[i].id == app.globalData.classid) {
        this.setData({
          "currentTab": i
        });
      }
    }
  },
  //点击切换
  clickTab: function (e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current,
        onReachBottom: true,//上拉刷新
        pageindex: 1,
      })
      
    }
  },
  swiperTab: function (e) {
    var tid=this.data.goodstype[this.data.currentTab].id;
    this.setData({
      currentTab: e.detail.current,
      onReachFBottom: true,//上拉刷新
      pageindex:1,
      // contHeight: this.data.goodslist[tid].goods.lenght*360
    });
    // console.log(this.data.goodslist[this.data.goodstype[this.data.currentTab].id]);
    this.getgoodslist();
    this.checkCor();
   
    if (this.data.goodslist[tid]){
      this.setData({
        contHeight: this.data.goodslist[tid].goods.length*360
      })
    }
    // console.log(this.data.goodslist);
  },
  //判断当前滚动超过一屏时，设置tab标题滚动条。
  checkCor: function () {
    if (this.data.currentTab > 4) {
      this.setData({
        scrollLeft: 300
      })
    } else {
      this.setData({
        scrollLeft: 0
      })
    }
  },
  //商品分类
  getgoodstype: function () {
    app.requestData({
      "url": "/api/goodstype/list",
      "success": res => {
        if (res.status) {
          var page =[];
          var len=res.data.length;

          for (var i=0;i<len;i++){
            page.push(1)
          }
          
          this.setData({
            goodstype: res.data,
            page:page,
          })
        } else {
          app.showTips(res.msg);
        }
        // console.log(this.data)
      }
    });
  },

  // 商品列表
  getgoodslist: function () {
    var that = this;
    var typeid = this.data.goodstype[this.data.currentTab].id;
    if (this.data.goodslist[typeid]) {
<<<<<<< HEAD
=======
        console.log('商品列表')
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
    } else {
      app.requestData({
        "url": "/api/goods/list",
        "subData": { "pageindex": this.data.pageindex, "pagesize": this.data.pagesize, "typeid": typeid },
        "success": res => {
          if (res.status) {
            var goodslist = that.data.goodslist;
            console.log('==================')
            var len = res.data.goods.length;//数据长度
            // var newHeight=this.data.contHeight*len + this.data.contHeight;//新高度
            var newHeight = 360 * len ;//新高度
            goodslist[typeid] = res.data;
            this.setData({
              goodslist: goodslist,
              contHeight:newHeight,
              typeid:typeid,
            })
          } else {
            app.showTips(res.msg);
          }
        }
      });
    }
  },
  //加入购物车
  addcart: function (e) {
    var goodid = e.currentTarget.dataset.id;
    var that = this;
    app.requestData({
      "url": "/api/goodscar/add",
      "subData": { "id": goodid, "number": 1 },
      "success": res => {
        if (res.status) {
          app.showTips(res.msg, function () {
            app.requestData({
              "url": "/api/goodscar/list",
              "success": res => {
                if (res.status) {
                  that.setData({
                    "cartnum": res.data.goodsCars.length
                  })
                } else {
                  app.showTips(res.msg);
                }
              }
            });
          });
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  //立即购买
  paybtn: function (e) {
    var goodid = e.currentTarget.dataset.id;
    var that = this;
    app.requestData({
      "url": "/api/order/place",
      "subData": { "goodsid": goodid, "number": 1 },
      "success": res => {
        if (res.status) {
          wx.navigateTo({
            url: '/pages/payment/payment',
          })
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  //拿到输入值
  wxSearchInput: function (e) {
    var val = e.detail.value;
    this.setData({
      inputval: val
    });
    // var that = this;
    if (val) {
      wx.navigateTo({
        url: '/pages/search/search?keyword=' + val
      })
    }
  },
<<<<<<< HEAD
=======

  // 下拉刷新回调接口
  onPullDownRefresh: function () {   
    // // 重新请求一遍数据
    var that = this;
    var typeid = this.data.goodstype[this.data.currentTab].id;
    app.requestData({
      "url": "/api/goods/list",
      "subData": { "pageindex": 1, "pagesize": this.data.pagesize, "typeid": typeid },
      "success": res => {
        if (res.status) {
          var goodslist = that.data.goodslist;
          console.log('==================')
          var len = res.data.goods.length;//数据长度
          // var newHeight=this.data.contHeight*len + this.data.contHeight;//新高度
          var newHeight = 360 * len;//新高度
          goodslist[typeid] = res.data;
          this.setData({
            goodslist: goodslist,
            contHeight: newHeight,
            typeid: typeid,
          })
        } else {
          app.showTips(res.msg);
        }
      }
    });
    console.log('刷新')
    wx.stopPullDownRefresh();
  },
  // 上拉加载
  onReachBottom: function () {
    
    // 网络请求
    // this.getgoodslist();
    
    var idx = this.data.pageindex+1;
    this.setData({
      pageindex:idx
    })
    var that = this;
    var typeid = this.data.goodstype[this.data.currentTab].id;
   
    if (this.data.onReachBottom == true) {
     console.log('上拉发送')
      app.requestData({
        "url": "/api/goods/list",
        "subData": { "pageindex": ++this.data.page[this.data.currentTab], "pagesize": this.data.pagesize, "typeid": typeid },
        "success": res => {
          if (res.status) {
            var len = res.data.goods.length;
            if (len <= 0) {
              this.setData({
                onReachBottom: false//关闭刷新
              })
            }
            var newHeight = 360* len + this.data.contHeight;//新高度
          
            var newlist = this.data.goodslist;

            for (var i = 0; i < len; i++) {
              console.log(i)
              console.log(res.data.goods)
              newlist[typeid].goods.push(res.data.goods[i]);
            }
            // console.log('=========')
            // console.log(newlist)
            // console.log(this.data.goodslist)

            this.setData({
              goodslist: newlist,
              contHeight:newHeight,
              typeid: typeid,
            })
          } else {
            app.showTips(res.msg);
          }
        }
      });
    } else {
     
      console.log('上拉失败else')

    }
  },
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
})