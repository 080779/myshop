// pages/mine/mine.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userinfo:{},
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.requestData({
      "url": "/api/usercenter/info",
      "success": res => {
        if (res.status) {
          for(var n in res.data){
            app.globalData.userInfo[n] = res.data[n]
          }
          this.setData({
            userinfo: app.globalData.userInfo,
            time: app.globalData.userInfo.createTime.split("",10).join("")
          });
        }
      }
    });
  }, 
})