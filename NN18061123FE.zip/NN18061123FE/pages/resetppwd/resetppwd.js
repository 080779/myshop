// pages/register/register.js
const util = require('../../utils/util.js')
const app = getApp();
Page({
  data: {
    phone: '',
    password: '',
    tradePassword: '',
    person: '',
    num: '',
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    sends: false,
    sendnum: 60,
  },
  onLoad: function () {
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        app.globalData.userInfo.code = res.code
      }
    })
    // setTimeout(this.sendnum,8000);
  },
  // 获取输入账号
  phoneInput: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },

  // 获取输入密码
  passwordInput: function (e) {
    this.setData({
      password: e.detail.value
    })
  },

  // 获取输入推荐人
  personInput: function (e) {
    this.setData({
      person: e.detail.value
    })
  },

  // 获取输入验证码
  numInput: function (e) {
    this.setData({
      num: e.detail.value
    })
  },

  //获取输入交易密码
  tradeInput: function (e) {
    this.setData({
      tradePassword: e.detail.value
    })
  },
  //发送验证码
  sendnum: function () {
    var that = this;
    var sendnum = that.data.sendnum;
    sendnum--
    if (sendnum > 0) {
      that.setData({
        sendnum: sendnum
      });
      setTimeout(function () {
        that.sendnum();
      }, 1000);
    } else {
      that.setData({
        sends: false,
        sendnum: 60
      });
    }

  },
  sendcode: function () {
    var that = this;
    if (this.data.sends) {
      return false;
    }
    if (this.data.phone.length == 0) {
      wx.showToast({
        title: '信息不能为空',
        icon: 'loading',
        duration: 2000
      })
    } else {
      this.setData({
        sends: true,
      });
      wx.request({
        "url": 'http://1823.demo.wohuicn.com/api/user/sendmsg',
        "data": {
          "mobile": this.data.phone,
        },
        "method": "POST",
        "header": {
          'content-type': 'application/json',
        },
        "success": function (res) {
          var data = res.data;
          if (data.status) {
            app.showToast({
              "tiptxt": "发送成功"
            });
            that.sendnum();
          } else {
            app.showTips(data.msg);
            this.setData({
              sends: false,
            });
          }
        },
        "fail": function (res) {
        }
      })
    }
  },

  // 登录
  login: function (detail) {
    if (this.data.phone<0 ||  this.data.num <0 || this.data.tradepassword < 0) {
      wx.showToast({
        title: '信息不能为空',
        icon: 'loading',
        duration: 2000
      })
    } else {
   

        app.requestData({
          "url": "/api/user/resetTradePwd",
          "subData": { "mobile": this.data.phone, "password": this.data.tradePassword, "code": this.data.num,},
          "success": res => {
            if (res.status) {
              wx.navigateBack({
                delta: 1
              })
            } else {
              app.showTips(res.msg);
            }
          },
        });
        
    
    }
  },
  bindGetUserInfo: function (e) {
    this.login(JSON.parse(e.detail.rawData));
  }
})

