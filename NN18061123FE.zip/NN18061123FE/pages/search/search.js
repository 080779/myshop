// pages/search/search.js
var app = getApp();
Page({
  data: {
    pageindex: 1,
    pagesize: 10,
<<<<<<< HEAD
    onReachBottom: true,
=======
    onReachBottom: true
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865

  },

  onLoad: function(options) {
    this.setData({
      "val": options.keyword
    });
    app.requestData({
      "url": "/api/goods/search",
<<<<<<< HEAD
      "subData": {
        "keyword": options.keyword,
        "pageindex": this.data.pageindex,
        "pagesize": this.data.pagesize,
      },
=======
      "subData": { "keyword": options.keyword, "pageindex": this.data.pageindex, "pagesize": this.data.pagesize },
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
      "success": res => {
        if (res.status) {
          this.setData({
            goodslist: res.data
          })
        }
      }
    });
  },
  //加入购物车
  addcart: function(e) {
    var goodid = e.currentTarget.dataset.id;
    var that = this;
    app.requestData({
      "url": "/api/goodscar/add",
      "subData": {
        "id": goodid,
        "number": 1,
      },
      "success": res => {
        if (res.status) {
          app.showTips(res.msg, function() {
            app.requestData({
              "url": "/api/goodscar/list",
              "success": res => {
                if (res.status) {
                  that.setData({
                    "cartnum": res.data.goodsCars.length
                  })
                } else {
                  app.showTips(res.msg);
                }
              }
            });
          });
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  //立即购买
  paybtn: function(e) {
    var goodid = e.currentTarget.dataset.id;
    var that = this;
    app.requestData({
      "url": "/api/order/place",
      "subData": {
        "goodsid": goodid,
        "number": 1
      },
      "success": res => {
        if (res.status) {
          wx.navigateTo({
            url: '/pages/payment/payment',
          })
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  //拿到输入值
<<<<<<< HEAD
  wxSearchInput: function(e) {
    var val = e.detail.value;
    app.requestData({
      "url": "/api/goods/search",
      "subData": {
        "keyword": val,
        "pageindex": 1,
        "pagesize": 6
      },
=======
  wxSearchInput: function (e) {
    var val = e.detail.value;
    app.requestData({
      "url": "/api/goods/search",
      "subData": { "keyword": val, "pageindex": 1, "pagesize": 6 },
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
      "success": res => {
        if (res.status) {
          this.setData({
            goodslist: res.data,
            val: val
          })
        }
        console.log(res)
      }
    });
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
<<<<<<< HEAD
  onPullDownRefresh: function() {
    this.setData({
      pageindex: 1
    })
=======
  onPullDownRefresh: function () {
    this.setData({
      pageindex: 1
    })
    // this.goodslist();
    wx.stopPullDownRefresh();
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
  },

  /**
   * 页面上拉触底事件的处理函数
   */
<<<<<<< HEAD
  onReachBottom: function() {
=======
  onReachBottom: function () {
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
    var index = this.data.pageindex;
    this.setData({
      pageindex: index + 1
    })
    console.log('上拉加载');
    if (this.data.onReachBottom == true) {
      app.requestData({
        "url": "/api/goods/search",
        "subData": {
          "pageindex": this.data.pageindex,
          "pagesize": this.data.pagesize,
          "keyword": this.data.val,
        },
        "success": res => {
          if (res.status) {
            var newlist = this.data.goodslist;
<<<<<<< HEAD
=======

>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
            console.log(newlist)
            var len = res.data.goods.length;
            if (len <= 0) {
              this.setData({
                onReachBottom: false,
              })
            }
<<<<<<< HEAD
            for (var i = 0; i < len; i++) {
              newlist.goods.push(res.data.goods[i]);
            }
=======

            for (var i = 0; i < len; i++) {

              newlist.goods.push(res.data.goods[i]);
            }

>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
            this.setData({
              goodslist: newlist
            })
          }
        }
      });
    }
  },
})