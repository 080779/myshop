// pages/payment/payment.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address: {},
    orderPlaces: [],
    totalAmount: 0,
    paytypelist: [],
    paytype: "",
    userinfo: {},
    discount: 1,
    open: false,
    PayTypeId: 0,
    tradePassword: '',
    isShowPassword: true
  },
  onLoad: function(option) {
    console.log(option)
    this.getpaytype();
    this.getplacelist();
    this.getdiscount();
    // this.deliverytype();
    if (!option.address) {
      this.getaddress();
    }
  },
  onShow: function() {
    this.getinfo();
    this.setData({
      address: app.globalData.defaultadd
    })
  },
  getinfo: function() {
    app.requestData({
      "url": "/api/usercenter/info",
      "success": res => {
        if (res.status) {
          for (var n in res.data) {
            app.globalData.userInfo[n] = res.data[n]
          }
          this.setData({
            userinfo: app.globalData.userInfo
          });
        }
      }
    });
  },
<<<<<<< HEAD
  //地址
  getaddress:function(addressid){
=======
  //获取地址
  getaddress: function(addressid) {
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
    var that = this;
    var url = "/api/address/default";
    if (addressid) {
      url = "/api/address/detail";
    }
    app.requestData({
      "url": url,
      "success": res => {
        if (res.status) {
          if (res.data) {
            app.globalData.defaultadd = res.data;
            this.setData({
              address: app.globalData.defaultadd
            })
          }
        } else {
          app.showTips(res.msg);
        }
      }
    })
  },

  //商品列表
  getpaytype: function() {
    var that = this;
    app.requestData({
      "url": "/api/order/placelist",
      "success": res => {
        if (res.status) {
          if (res.data.orderPlaces.length) {
            that.setData({
              orderPlaces: res.data.orderPlaces,
              totalAmount: res.data.totalAmount,
            })
          } else {
            wx.switchTab({
              url: '/pages/home/home'
            })
          }
        } else {
          app.showTips(res.msg);
        }
      }
    })
  },
  //改变收货类型
  // changedeliverytype: function (e) {
  //   var value = e.detail.value
  //   this.setData({
  //     deliverytype: this.data.deliverytypelist[value],
  //   })
  // },
  //收货类型
  // deliverytype: function (e) {
  //   app.requestData({
  //     "url": '/api/order/deliverytype',
  //     // "subData": { "orderId": e.target.dataset.orderid },
  //     "success": res => {
  //       if (res.status) {
  //         var deliverytype = [];
  //         for (var i=0;i<res.data.deliveryTypes.length;i++){
  //           deliverytype.push(res.data.deliveryTypes[i].tpye);
  //         }
  //         this.setData({
  //           deliverytype: deliverytype[0],
  //           deliverytypelist: deliverytype,
  //           deliverytypelists: res.data.deliveryTypes,
  //         })
  //         console.log(this.data.deliverytype)
  //       } else {
  //         app.showTips(res.msg);
  //       }
  //     }
  //   });
  // },
  //支付类型
  getplacelist: function() {
    var that = this;
    app.requestData({
      "url": "/api/paytype/list",
      "success": res => {
        if (res.status) {
          var list = [];
          for (var i = 0; i < res.data.length; i++) {
            list.push(res.data[i].name);
          }
          that.setData({
            paytypelist: list,
            paytype: list[0],
            paytypelists: res.data,
          })
        } else {
          app.showTips(res.msg);
        }
      }
    })
  },
  //微信支付
  wxpay: function(obj) {
    wx.requestPayment({
      'timeStamp': obj.timeStamp,
      'nonceStr': obj.nonceStr,
      'package': obj.package,
      'signType': 'MD5',
      'paySign': obj.paySign,
      'success': function(res) {
        wx.redirectTo({
          url: '/pages/myorders/myorders'
        })
      },
      'fail': function(res) {
        wx.redirectTo({
          url: '/pages/myorders/myorders'
        })
        console.log(res)
      }
    })
  },
  //改变支付类型
  changepaytype: function(e) {
    var value = e.detail.value
    this.setData({
      paytype: this.data.paytypelist[value],
    })
  },
  //验证密码
  settype: function() {
    if (this.data.PayTypeId == 11) {
      this.setData({
        open: true
      })
    }
    // if (this.data.tradePassword!=''){
    //   app.requestData({
    //     "url": "/api/order/valid",
    //     "subData": { tradePassword: this.data.tradePassword },
    //     "success": res => {
    //       if (res.status) {
    //         // that.setData({
    //         //   discount: res.data
    //         // });
    //         console.log(res.data);
    //       }
    //     }
    //   })
    // }



  },
  //支付
  pay: function() {
    var that = this;
    var PayTypeId = 0;
    // var DeliveryTypeId = 0;
    if (!this.data.address.id) {
      app.showTips('请选择地址');
      return false;
    }
    for (var i = 0; i < this.data.paytypelists.length; i++) {
      if (this.data.paytypelists[i].name == this.data.paytype) {
        PayTypeId = this.data.paytypelists[i].id;
        break;
      }
    }
<<<<<<< HEAD
    var menoyUrl = "/api/order/applys";
    if (PayTypeId==12){
      menoyUrl = "/api/order/pay"
    }
    app.requestData({
      "url": menoyUrl,
      "subData": { "PayTypeId": PayTypeId,"AddressId":this.data.address.id},
=======
    this.setData({
      PayTypeId: PayTypeId
    })
    // for (var i = 0; i < this.data.deliverytypelists.length; i++) {
    //   if (this.data.deliverytypelists[i].tpye == this.data.deliverytype) {
    //     DeliveryTypeId = this.data.deliverytypelists[i].id;
    //     break;
    //   }
    // }
    if (PayTypeId == 12) {
      var  menoyUrl = "/api/order/pay"
      app.requestData({
        "url": menoyUrl,
        "subData": {
          "PayTypeId": PayTypeId,
          "AddressId": this.data.address.id,
          // DeliveryTypeId
        },
        "success": res => {
          if (res.status) {
            that.wxpay(res.data);
          } else {
            app.showTips(res.msg);
          }
        },
      })
    } else {
      this.settype();
    }
  },
  //折扣
  getdiscount: function() {
    var that = this;
    app.requestData({
      "url": "/api/order/discount",
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
      "success": res => {
        if (res.status) {
          that.setData({
            discount: res.data
          });
          console.log(that.data);
        }
      }
    })
  },
  passInput(e) {
    var that = this;
    this.setData({
      open: e.detail.active
    })
    if (e.detail.val == '') {
      return false
    }
    this.setData({
      tradePassword: e.detail.val
    })
    if (this.data.tradePassword != '') {
      app.requestData({
        "url": "/api/order/valid",
        "subData": {
          tradePassword: this.data.tradePassword
        },
        "success": res => {
          if (res.status) {
            app.requestData({
              "url": '/api/order/applys',
              "subData": {
                "PayTypeId": this.data.PayTypeId,
                "AddressId": this.data.address.id,
                // DeliveryTypeId
              },
              "success": res => {
                if (res.status) {
                  if (this.data.PayTypeId == 12) {
                    that.wxpay(res.data);
                  } else {
                    app.showTips(res.msg, function() {
                      wx.redirectTo({
                        url: '/pages/myorders/myorders'
                      })
                    });
                  }
                } else {
                  app.showTips(res.msg, function () {
                    wx.redirectTo({
                      url: '/pages/myorders/myorders'
                    })
                  });
                }
              },
            })

          } else {
            app.showTips(res.msg);
          }
        }
      })
    }
  },
})