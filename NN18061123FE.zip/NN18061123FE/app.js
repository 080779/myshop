//app.js
App({
  onLaunch: function () {

    wx.hideShareMenu({
      
    })
    
    // 展示本地存储能力
    this.globalData.userInfo.token = wx.getStorageSync('token') || ""
    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        this.globalData.userInfo.code = res.code
      }
    })
   
    // wx.getSetting({
    //   success: function (res) {
    //     if (res.authSetting['scope.userInfo']) {
    //       wx.getUserInfo({
    //         success: res => {
    //           for (var n in res.userInfo) {
    //             app.globalData.userInfo[n] = res.userInfo[n]
    //           }
    //         }
    //       })
    //     }
    //   }
    // })   
    
  },
  globalData: {
    userInfo: {},
    goodstype:{},
    classid:0,
    defaultadd:{},
  },
  requestData: function (options) {
    var that = this;
    var url = options.url || '';
    var subData = options.subData || {};
    if (!that.globalData.userInfo.token) {
      wx.navigateTo({
        url: '/pages/login/login'
      })
      return false;
    }else{
      subData.token = that.globalData.userInfo.token;
    }
    var success = options.success || function () { };
    var fail = options.fail || function () { };
    var complete = options.complete || function () { };
    wx.request({
      "url": 'http://1823.demo.wohuicn.com' + url,
      "data": subData,
      "method": "POST",
      "header": {
        'content-type': 'application/json',
        "token": that.globalData.userInfo.token,
      },
      "success": function (res) {
        var data = res.data;
        if(data.Message=="会员不存在"){
          wx.removeStorageSync('token');
          wx.navigateTo({
            url: '/pages/login/login',
          })

        }else{
          success && success(data);
        }
        
      },
      "fail": function (res) {
        var data = res;
        fail && fail(data);
      },
      "complete": function () {
        complete && complete();
      }
    })
  },
  //提示信息
  showTips: function (tiptxt, success) {
    wx.showModal({
      title: '',
      content: tiptxt ? tiptxt : "",
      showCancel: false,
      success: success ? success : function () { }
    })
  },
  showToast: function (option){
    wx.showToast({
      title: option.tiptxt ? option.tiptxt : "",
      icon: option.icon ? option.icon:'success',
      duration: 2000,
      success: option.success ? option.success : function () { }
    })
  },
})