// pages/goodsitem/goodsitem.js
const app = getApp();
Page({
  data: {
    detail:{},
    goodid:0,
    cartnum:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var scene = decodeURIComponent(options.scene);
    var t_uid = options.t_uid ? options.t_uid : null;
    if (options.scene && scene != 'undefined') {
      options.id = scene;
    }
    this.setData({
      "goodid": options.id,
      "t_uid": t_uid,
    })
    this.updatecart();
    this.getdetail();
  },

  // 商品详情
  getdetail: function () {
    var goodid = this.data.goodid;
    app.requestData({
      "url": "/api/goods/detail",
      "subData": { "id": goodid },
      "success": res => {
        if (res.status) {
          this.setData({
            datail: res.data,
            description: res.data.description.replace(/\<img/gi, '<img style="max-width:100%;height:auto" '),//设置解析的图片
          })
          console.log(this.data.description);
          wx.setNavigationBarTitle({
            "title": res.data.name
          })
        }
      }
    });
  },
  //立即购买
  paybtn: function () {
    var goodid = this.data.goodid;
    var that = this;
    app.requestData({
      "url": "/api/order/place",
      "subData": { "goodsid": goodid, "number": 1 },
      "success": res => {
        if (res.status) {
          wx.navigateTo({
            url: '/pages/payment/payment',
          })
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  //加入购物车
  addcart:function(){
    var goodid = this.data.goodid;
    var that = this;
    app.requestData({
      "url": "/api/goodscar/add",
      "subData": { "id": goodid,"number":1 },
      "success": res => {
        if (res.status) {
          app.showTips(res.msg,function(){
            that.updatecart();
          });
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  //
  updatecart:function(){
    var that = this;
    app.requestData({
      "url": "/api/goodscar/list",
      "success": res => {
        if (res.status) {
          that.setData({
            "cartnum": res.data.goodsCars.length
          })
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
})