// pages/record/record.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
<<<<<<< HEAD
    list:[],
    pageindex:1,
    pagesize:5
=======
    list: '',
    pageindex: 1,
    pagesize: 10,
    onReachBottom:true,//上拉加载
    newlist: ''
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
  },
  getlist: function() {
    app.requestData({
      "url": "/api/takecash/list",
<<<<<<< HEAD
      "subData": { 
        "pageindex": options.pageindex, 
        "pagesize":options.pagesize,
        },
=======
      "subData": {
        "pageindex": this.data.pageindex,
        "pagesize": this.data.pagesize,
      },
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
      "success": res => {
        if (res.status) {
          var len = res.data.takeCashes.length;
          for (var i = 0; i < len; i++) {
            res.data.takeCashes[i].createTime = res.data.takeCashes[i].createTime.replace("T", " ").split("", 16).join("")
          }
          this.setData({
<<<<<<< HEAD
            list: res.data
=======
            list: res.data.takeCashes,
            onReachBottom: true//允许上拉加载
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
          });
        }
      }
    });
    console.log(this.data)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getlist();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.setData({
      pageindex: 1
    })
    this.getlist();
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    var idx = this.data.pageindex;//页数
    this.setData({
      pageindex: idx + 1
    })
   
    
    if (this.data.onReachBottom==true){
      app.requestData({
        "url": "/api/takecash/list",
        "subData": {
          "pageindex": this.data.pageindex,
          "pagesize": this.data.pagesize,
        },
        "success": res => {
          if (res.status) {
            var len = res.data.takeCashes.length;
            if (len <= 0) {
              this.setData({
                onReachBottom: false//关闭刷新
              })
            }
            var newlist = this.data.list;
            //数据拼接
            for (var i = 0; i < len; i++) {
              console.log(i)
              newlist.push(res.data.takeCashes[i]);
              res.data.takeCashes[i].createTime = res.data.takeCashes[i].createTime.replace("T", " ").split("", 16).join("")
            }
            this.setData({
              list: newlist
            })
            console.log(this.data.list)
          }
        }
      });
    }

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})