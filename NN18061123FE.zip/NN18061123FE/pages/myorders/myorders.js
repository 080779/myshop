// pages/shop/shop.js
var app = getApp()
Page({
  data: {
    list:{},
    state:[{"id":0,"name":"全部"}],
<<<<<<< HEAD
    scrollLeft: 0, //tab标题的滚动条位置
    currentTab: 0
=======
    currentTab: 0,
    onReachBottom:true,
    pagesize:5,
    scrollLeft: 0, //tab标题的滚动条位置
    contHeight:800,
    num:0,//计数
    paytype: "",
    paytypelist: [],
    active:true,
    open:false,
    tradePassword:''//交易密码
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    this.getstate();
    this.getlist();
    this.getplacelist();
    // this.deliverytype();
    // this.getbtnstate();
  },
  //判断当前滚动超过一屏时，设置tab标题滚动条。
  checkCor: function () {
    if (this.data.currentTab > 4) {
      this.setData({
        scrollLeft: 300
      })
    } else {
      this.setData({
        scrollLeft: 0
      })
    }
  },
  //点击切换
  clickTab: function (e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current,
        onReachBottom: true//刷新
      })
    }
  },
  swiperTab: function (e) {
    this.getlist();
    this.setData({
      currentTab: e.detail.current,
      pageindex:1,
    });
<<<<<<< HEAD
    this.checkCor();
=======
    this.getlist();
    this.checkCor();
    if (this.data.list[e.detail.current]) {
      // console.log('=====a=aa=a=a=')
     
      var len = this.data.list[e.detail.current].Orders.length;
      var oderlen = len * 140*2;//外面的高度
      var goodslen = 0;
      for (var i = 0; i < len; i++) {
        goodslen = goodslen + this.data.list[e.detail.current].Orders[i].OrderGoods.length
        res.data.Orders[i].createTime = res.data.Orders[i].createTime.replace("T"," ").split("",16).join("")
      }
      var oderHeight = goodslen * 140*2 + oderlen;
      this.setData({
        contHeight: oderHeight
      })
    }else{
      this.setData({
        contHeight: 600
      })
    }
  },
  //判断当前滚动超过一屏时，设置tab标题滚动条。
  checkCor: function () {
    if (this.data.currentTab > 4) {
      this.setData({
        scrollLeft: 300
      })
    } else {
      this.setData({
        scrollLeft: 0
      })
    }
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
  },
  //列表
  getlist:function(){
    var list = this.data.list;
    var subData = { "pageindex": 1, "pagesize": this.data.pagesize};
    if (this.data.currentTab){
      subData["orderStateId"] = this.data.state[this.data.currentTab].id;
    }
    app.requestData({
      "url": "/api/order/list",
      "subData": subData,
      "success": res => {
        if (res.status) {
          var len = res.data.Orders.length;
          var oderlen = len *140*2;//外面的高度
          var goodslen = 0;
          for(var i=0;i<len;i++){
            goodslen = goodslen + res.data.Orders[i].OrderGoods.length
            res.data.Orders[i].createTime = res.data.Orders[i].createTime.replace("T"," ").split("",16).join("")
          }
          var oderHeight = goodslen * 140*2 + oderlen;
          // console.log('=========cesss')
          // console.log(goodslen)
          // console.log(oderHeight)
          if (len <= 0) {
            this.setData({
              onReachBottom: false,//关闭刷新
            })
          }else{
            this.setData({
              contHeight: oderHeight,//总高度
            })
          }
          list[this.data.currentTab] = res.data
          this.setData({
            list: list, 
          });
        }
        // console.log(this.data)
      }
    });
  },
  //获取状态
  getstate:function(){
    app.requestData({
      "url": "/api/order/state",
      "success": res => {
        if (res.status) {
          var states = [{ "id": 0, "name": "全部" }]
          var page=[]

          for(var n=0;n<res.data.length;n++){
            states.push(res.data[n]);
            page.push(1);
          }
          this.setData({
            state: states,
            page:page
          });
        }
      }
    });
  },
<<<<<<< HEAD
})
=======
  // 下拉刷新回调接口
  onPullDownRefresh: function () {
    // // 重新请求一遍数据
    this.getlist();
    wx.stopPullDownRefresh();
  },
  // 上拉加载
  onReachBottom: function (){
    // var idx = this.data.pageindex + 1;
    // this.setData({
    //   pageindex: idx
    // })
    var that = this;

    if (this.data.onReachBottom == true) {
      var subData = { "pageindex": ++this.data.page[this.data.currentTab], "pagesize": this.data.pagesize };
      if (this.data.currentTab) {
        subData["orderStateId"] = this.data.state[this.data.currentTab].id;
      }
      app.requestData({
        "url": "/api/order/list",
        "subData": subData,
        "success": res => {
          if (res.status) {
            var len = res.data.Orders.length;
            var oderlen = len * 140*2;//外面的高度
            var goodslen = 0;
            for (var i = 0; i < len; i++) {
              goodslen = goodslen + res.data.Orders[i].OrderGoods.length
              res.data.Orders[i].createTime = res.data.Orders[i].createTime.replace("T"," ").split("",16).join("")
            }
            var oderHeight = goodslen * 140*2 + oderlen + this.data.contHeight;
            
            
            if (len <= 0) {
              this.setData({
                onReachBottom: false//关闭刷新
              })
            } else {
              this.setData({
                contHeight: oderHeight,//总高度
              })
            }
            
            var newlist = this.data.list;

            for (var i = 0; i < len; i++) {
         
              newlist[this.data.currentTab].Orders.push(res.data.Orders[i]);
            }
  
            this.setData({
              list: newlist,
            })
          } else {
            // app.showTips(res.msg);
          }
        }
      });
    } else {


    }
  },
  //改变支付类型
  changepaytype: function (e) {
    var value = e.detail.value
    this.setData({
      paytype: this.data.paytypelist[value],
      payTypeName: this.data.paytypelist[value]
    })
    if (this.data.payTypeName=='余额'){
      this.setData({
        open:true
      })
   
 }
    this.pay()
  },
  //支付类型：余额/微信
  getplacelist: function () {
    var that = this;
    app.requestData({
      "url": "/api/paytype/list",
      "success": res => {
        if (res.status) {
          var list = [];
          for (var i = 0; i < res.data.length; i++) {
            list.push(res.data[i].name);
          }
          that.setData({
            paytypelist: list,
            paytype: list[0],
            paytypelists: res.data,
          })
        } else {
          app.showTips(res.msg);
        }
      }
    })
  },
  //微信支付
  wxpay: function (obj) {
    wx.requestPayment({
      'timeStamp': obj.timeStamp,
      'nonceStr': obj.nonceStr,
      'package': obj.package,
      'signType': 'MD5',
      'paySign': obj.paySign,
      'success': function (res) {
        // wx.navigateTo({
        //   url: '/pages/myorders/myorders'
        // })
      },
      'fail': function (res) {
        // console.log(res)
      }
    })
  },
  changepay:function(e){
    var that=this;
    this.setData({
      orderId: e.target.dataset.orderid,
      payTypeName:e.target.dataset.paytypename,
      
    })
  },
  //支付
  pay: function(e){
    // var orderId = e.target.dataset.orderid;
    // var payTypeName = e.target.dataset.paytypename;
    
 
    var url = "/api/order/reapplys"
    if (this.data.payTypeName=='微信'){
      url ="/api/order/repay";
      app.requestData({
        "url": url,
        "subData": { "orderId": this.data.orderId },
        "success": res => {
          if (res.status) {
            this.getlist();
            this.wxpay(res.data);
          } else {
            app.showTips(res.msg);
          }
        }
      });
    }
    
    // console.log(e.target.dataset.orderid);
  },
  //删除订单
  discount:function(e){
    app.requestData({
      "url": '/api/order/del',
      "subData": { "id": e.target.dataset.orderid },
      "success": res => {
        if (res.status) {
          app.showTips(res.msg);
          this.getlist();//刷新
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  //查看快递单
  getDeliveryCode: function (e) {
    // app.requestData({
    //   "url": '/api/order/getDeliveryCode',
    //   "subData": { "orderId": e.target.dataset.orderid },
    //   "success": res => {
    //     if (res.status) {
    //       app.showTips('快递单号：' + res.data.deliverCode + '(' + res.data.deliverName+')');
    //       // console.log()
    //     } else {
    //       app.showTips(res.msg);
    //     }
    //   }
    // });
    if (e.target.dataset.deliver=='有快递单号'){
      app.showTips('快递单号：' + e.target.dataset.deliverycode + '(' + e.target.dataset.deliveryname + ')');
      console.log(e.target.dataset)
    }else{
      console.log(e.target.dataset)
      app.showTips(e.target.dataset.deliver);
    }
      
    
    
  },
  //确认收货
  receipt:function(e){
    app.requestData({
      "url": '/api/order/receipt',
      "subData": { "orderId": e.target.dataset.orderid },
      "success": res => {
        if (res.status) {
          app.showTips(res.msg);
          this.getlist();//刷新
        } else {
          app.showTips(res.msg);
        }
      }
    });
  },
  //收货类型
  // deliverytype: function (e) {
  //   app.requestData({
  //     "url": '/api/order/deliverytype',
  //     // "subData": { "orderId": e.target.dataset.orderid },
  //     "success": res => {
  //       if (res.status) {
  //        this.setData({
  //          deliverytype: res.data.deliveryTypes
  //        })
  //         console.log(this.data.deliverytype)
  //       } else {
  //         app.showTips(res.msg);
  //       }
  //     }
  //   });
  // }
  passInput(e) {
    var that = this;
    this.setData({
      open: e.detail.active
    })
    if (e.detail.val=='') {
      return false
    }
    this.setData({
      tradePassword: e.detail.val
    })
    if (this.data.tradePassword != '') {
      app.requestData({
        "url": "/api/order/valid",
        "subData": {
          tradePassword: this.data.tradePassword
        },
        "success": res => {
          if (res.status) {
            // this.setData({
            //   open: false
            // })
            app.requestData({
              "url": '/api/order/reapplys',
              "subData": { "orderId": this.data.orderId },
              "success": res => {
                if (res.status) {
                  if (this.data.PayTypeId == 12) {
                    that.wxpay(res.data);
                  } else {
                    app.showTips(res.msg, function () {
                      wx.navigateTo({
                        url: '/pages/myorders/myorders'
                      })
                    });
                  }
                } else {
                  app.showTips(res.msg, function () {
                    wx.navigateTo({
                      url: '/pages/myorders/myorders'
                    })
                  });
                }
              }
            })

          } else {
            app.showTips(res.msg);
          }
        }
      })
    }
  },

  //退单申请
  refund:function(e){
    app.requestData({
      "url": '/api/refund/apply',
      "subData": { "orderId": e.target.dataset.orderid },
      "success": res => {
        if (res.status) {
          app.showTips(res.msg);
          this.getlist();//刷新
        } else {
          app.showTips(res.msg);
        }
      }
    });
  }
})
>>>>>>> 7a7f26166642a9fedc83d22bbbb594f0a520d865
