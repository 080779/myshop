// pages/myblance/myblance.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: '',
    pageindex: 1,
    pagesize: 20,
    onReachBottom: true,
  },
  //获取账户信息
  userinfo: function () {
    app.requestData({
      "url": "/api/usercenter/info",
      "success": res => {
        if (res.status) {
          for (var n in res.data) {
            app.globalData.userInfo[n] = res.data[n]
          }
          this.setData({
            userInfo: res.data
          });
        }
      }
    });
  },
  //获取流水记录
  getrecord: function () {
    app.requestData({
      "url": "/api/journal/list",
      "subData": { "pageindex": this.data.pageindex, "pagesize": this.data.pagesize },
      "success": res => {
        if (res.status) {
          this.setData({
            list: res.data.journals
          });
        }
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      userInfo: app.globalData.userInfo
    });
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.userinfo();//用户信息
    this.getrecord();//记录
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      pageindex: 1
    })
    this.getrecord();
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */

  onReachBottom: function () {
    if (this.data.onReachBottom == true){
     app.requestData({
       "url": "/api/journal/list",
       "subData": { "pageindex": ++this.data.pageindex, "pagesize": this.data.pagesize },
       "success": res => {
         if (res.status) {

           var len = res.data.journals.length;
           if (len <= 0) {
             this.setData({
               onReachBottom: false//关闭刷新
             })
           }
           var newlist = this.data.list;
           for (var i = 0; i < len; i++) {
             console.log(i)
             console.log(res.data.journals)
             console.log(newlist)
             newlist.push(res.data.journals[i]);
           }
           this.setData({
             list: newlist
           })
         } else {
          //  app.showTips(res.msg);
         }
       }
     });
   }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})